package commands;

import java.io.FileNotFoundException;

import exceptions.ArrayException;
import main.Engine;

public class LoadFich extends Command {
	private String fichName;
	
	/**
	 * constructor
	 * @param fich nombre del fichero
	 */
	public LoadFich(String fich){
		this.fichName = fich;
	}
	
	/**
	 * Carga el fichero si no ha sido posible lanza una excepcion
	 */
	@Override
	public boolean execute(Engine engine) throws ArrayException{
		try {
			engine.executeLoad(this.fichName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return true;
	}

	/**
	 * Parsea el string y crea el fichero si este es correcto sino devuelve null
	 */
	@Override
	public Command parse(String[] s) {
		String mayus = s[0].toUpperCase();
		if(s.length == 2 && mayus.equalsIgnoreCase("LOAD")){
			this.fichName = s[1];
			return new LoadFich(this.fichName);
		}else
		return null;
	}

	/**
	 * Mensaje de ayuda
	 */
	@Override
	public String textHelp() {
		return "Carga el fichero de nombre FICH como programa fuente. No realiza ningun tipo de comprobacion sintactica";
	}
	
	/**
	 * Devuelve el string de carga de fichero 
	 */
	public String toString(){
		return new String("LOADFICH " + this.fichName);
	} 

}
