package commands;

import java.io.FileNotFoundException;

import exceptions.ArrayException;
import exceptions.BadFormatByteCode;
import exceptions.ExecutionError;
import exceptions.LexicalAnalysisException;
import main.Engine;

public abstract class Command {
	/**
	 * metodo abstracto
	 * @param engine engine
	 * @return si se ha ejecutado correctamente
	 * @throws ExecutionError 
	 * @throws FileNotFoundException 
	 * @throws BadFormatByteCode 
	 */
	abstract public boolean execute(Engine engine) throws LexicalAnalysisException, ArrayException, ExecutionError, FileNotFoundException, BadFormatByteCode;
	
	/**
	 * comprueba la cadena de string
	 * @param s cadena de string
	 * @return command
	 */
	abstract public Command parse(String[] s);
	
	/**
	 * texto de ayuda
	 * @return string
	 */
	abstract public String textHelp();
}
