package commands;

import exceptions.ArrayException;
import exceptions.BadFormatByteCode;
import main.Engine;

public class Replace extends Command {
	private int n;

	/**
	 * const
	 * 
	 * @param n
	 *            numero
	 */
	public Replace(int n) {
		this.n = n;
	}

	/**
	 * ejecuta replace
	 * 
	 * @throws ArrayException
	 * @throws BadFormatByteCode 
	 */
	@Override
	public boolean execute(Engine engine) throws ArrayException, BadFormatByteCode {
		
		return engine.executeREPLACE(this.n);
		/*
		try {
			return engine.executeREPLACE(this.n);
		} catch (BadFormatByteCode e) {
			return false;
		}
		*/
	}

	/**
	 * comprueba comando replace lo crea sino null
	 */
	@Override
	public Command parse(String[] s) {
		
		Command command = null;
		String mayus = s[0].toUpperCase();
		if ((s.length == 2) && mayus.equalsIgnoreCase("REPLACE")){
			try {
				this.n = Integer.parseInt(s[1]);
				command = new Replace(this.n);
			}
			catch (NumberFormatException e){
				command = null;
			}
		}
		return command;
		
		/*
		String mayus = s[0].toUpperCase();
		if (s.length == 2 && mayus.equalsIgnoreCase("REPLACE")) {
			this.n = Integer.parseInt(s[1]);
			return new Replace(this.n);
		} else
			return null;
			*/
	}

	/**
	 * muestra ayuda replace
	 */
	@Override
	public String textHelp() {
		return "REPLACE: Sustituye una instruccion ";
	}

	/**
	 * devuelve replace n
	 */
	public String toString() {
		return new String("REPLACE " + n);
	}

}
