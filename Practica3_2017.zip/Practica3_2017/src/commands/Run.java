package commands;

import exceptions.ArrayException;
import exceptions.ExecutionError;
import main.Engine;

public class Run extends Command {

	/**
	 * ejecuta run
	 * @throws ArrayException 
	 */
	@Override
	public boolean execute(Engine engine) throws ExecutionError, ArrayException{
		// TODO Auto-generated method stub
		return engine.executeRUN();
	}

	/**
	 * comprueba comando run lo crea sino null
	 */
	@Override
	public Command parse(String[] s) {
		String mayus = s[0].toUpperCase();
		if (s.length == 1 && mayus.equalsIgnoreCase("RUN"))
			return new Run();
		else 
		return null;
	}

	/**
	 * muestra ayuda run
	 */
	@Override
	public String textHelp() {
		return "RUN: Ejecuta el programa actual ";
	}
	
	/**
	 * devuelve string run
	 */
	public String toString(){
		return new String ("RUN");
	}
}
