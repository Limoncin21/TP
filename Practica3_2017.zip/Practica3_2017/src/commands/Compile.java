package commands;

import exceptions.ArrayException;
import exceptions.LexicalAnalysisException;
import main.Engine;

public class Compile extends Command {

	/**
	 * ejecuta y genera su respectivo bytecode
	 */
	@Override
	public boolean execute(Engine engine) throws ArrayException, LexicalAnalysisException {
		engine.compile();
		return true;
	}

	/**
	 * Parsea el string y comprueba si es una cadena correcta de compile si es asi crea el compile
	 */
	@Override
	public Command parse(String[] s) {
		String mayus = s[0].toUpperCase();
		if (s.length == 1 && mayus.equalsIgnoreCase("COMPILE"))
			return new Compile();
		else
			return null;
	}

	/**
	 * mensaje de ayuda
	 */
	@Override
	public String textHelp() {
		return "Realiza el analisis lexico del programa fuente, generando un nuevo programa parseado y, "
				+ "posteriormente a partir del programa parseado genera un programa bytecode";
	}

	/**
	 * String de Compile
	 */
	public String toString() {
		return new String("COMPILE");
	}

}
