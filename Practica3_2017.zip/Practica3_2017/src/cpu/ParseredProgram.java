package cpu;

import exceptions.ArrayException;
import instructions.Instruction;

public class ParseredProgram {
	private Instruction[] pProgram;
	private int marco;
	public static int MAX_INSTR = 100;

	/**
	 * Constructor que inicializa el programa y el marco a 0
	 */
	public ParseredProgram() {
		inicializarPProgram();
		this.marco = 0;
	}

	/**
	 * Inicializa el array de instrucciones
	 */
	public void inicializarPProgram() {
		pProgram = new Instruction[MAX_INSTR];
	}

	/**
	 * A�ade una instruccion
	 * @param instr instrucion
	 * @throws ArrayException excepcion de array
	 */
	public void a�adirInstr(Instruction instr) throws ArrayException {
		//si no remensionamos hay que poner eso
		/*
		if (marco == MAX_INSTr){
			throw new ArrayException("Excepcion: Limite de instrucciones alcanzado");
		}
		else{
			pProgram[marco] = instr;
			marco++;
		}
		*/
		pProgram[marco] = instr;
		marco++;
	}

	/**
	 * Devuelve el numero de instrucciones que hay
	 * @return marco
	 */
	public int getNumeroInstrucciones() {
		return this.marco;
	}
	/**
	 * Vac�a el array de sPrograms y pone el marco a 0
	 */
	public void vaciarArray() {
		for (int i = 0; i < marco; i++) {
			pProgram[i] = null;
		}
		marco = 0;
	}
	/**
	 * Devuelve la instruccion que esta en una determinada posicion
	 * @param pos posicion
	 * @return instruccion
	 * @throws ArrayException
	 */
	public Instruction getInstruction(int pos) throws ArrayException {
		return pProgram[pos];
	}

	/**
	 * Devuelve los string de el programa almacenado
	 */
	public String toString() {
		String cadena = "Programa almacenado:" + System.getProperty("line.separator");
		for (int i = 0; i < marco; i++) {
			cadena += i + ": " + pProgram[i].toString() + System.getProperty("line.separator");
		}
		return cadena;
	}
}
