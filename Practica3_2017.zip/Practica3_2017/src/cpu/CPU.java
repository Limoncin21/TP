package cpu;

import main.ByteCodeProgram;
import bytecodes.ByteCode;
import exceptions.ArrayException;
import exceptions.ExecutionError;
import exceptions.StackException;

public class CPU {
	private Memory mem;
	private OperandStack pila;
	private boolean parada;
	private int programCounter;
	private ByteCodeProgram bcProgram;

	/**
	 * Constructor
	 */
	public CPU(ByteCodeProgram program) {
		bcProgram = program;
		programCounter = 0;
		mem = new Memory();
		pila = new OperandStack();
		parada = false;
	}

	/**
	 * resetea cpu
	 */
	public void reset() {
		mem.reset();
		pila.reset();
		parada = false;
		programCounter = 0;
	}

	/**
	 * ejecuta la cpu
	 * 
	 * @return true
	 * @throws ArrayException
	 */
	public boolean run() throws ExecutionError, ArrayException {
		
		boolean ok = true;
		this.reset();
		while (!parada && programCounter < bcProgram.getMarco() && ok){
			ByteCode byteCode = bcProgram.devolverInstruccion(programCounter);
			try {
				ok = byteCode.execute(this);
			}
			catch (ExecutionError e){
				throw new ExecutionError(e.getMessage() + " (bytecode " + this.programCounter + ").");
			}
		}
		return ok;
		
		/*
		boolean ok = true;
		while (!parada && programCounter < bcProgram.getMarco() && ok) {
			ByteCode byteCode = bcProgram.devolverInstruccion(programCounter);
			if (byteCode != null) {
				try {
					ok = byteCode.execute(this);
				} catch (DivisionByZero e) {
					System.out.println("Excepcion producida en la instruccion " + programCounter+":");
					System.out.println(e.toString());
				}
			} else {
				ok = false;
			}
		}
		return ok;
		*/
	}

	/**
	 * cambia el boolean parada
	 * 
	 * @return true
	 */
	public boolean halt() {
		parada = !parada;
		return true;
	}

	/**
	 * lee el ultimo elemento
	 * 
	 * @return true
	 */
	public boolean out() {
		boolean ok = false;
		int top = pila.leerUltElemt();
		if (!pila.isEmpty()) {
			System.out.println("Operand stack's top is: " + top);
			ok = true;
		}
		return ok;
	}

	/**
	 * A�ades la instruccion de bcProgram al byteCode para usarla en el run de
	 * cpu
	 * 
	 * @param bc
	 *            bytecode
	 * @param pos
	 *            posicion
	 * @return true si hay bytecode false si no
	 * @throws ArrayException
	 */
	public boolean a�adirInstruccion(ByteCode bc, int pos) throws ArrayException {
		bc = bcProgram.devolverInstruccion(pos);
		if (bc != null)
			return true;
		else
			return false;
	}

	/**
	 * mete elemento en la pila
	 * 
	 * @param n
	 *            numero
	 * @return si se ha podido meter o no el elemento
	 * @throws StackException
	 */
	public boolean push(int n) throws StackException {		
		boolean ok = pila.meterElemento(n);
		if (!ok){
			throw new StackException("Longitud de pila insuficiente");
		}
		else{
			return ok;
		}	
		//return pila.meterElemento(n);
	}

	/**
	 * saca el ultimo elemento de la pila eliminandolo
	 * 
	 * @return si se ha podido sacar o no
	 * @throws StackException
	 */
	public int pop() throws StackException {
		return pila.sacarElemento();
	}

	/**
	 * lee el ultimo elemento de la pila
	 * 
	 * @return si se ha podido leer o no
	 */
	public int readPila() {
		return pila.leerUltElemt();
	}

	/**
	 * lee de memoria
	 * 
	 * @param n
	 *            numero
	 * @return si se ha podido leer o no
	 */
	public int readMem(int n) {
		return mem.read(n);
	}

	/**
	 * Lee la posicion de la memoria
	 * @param pos posicion
	 * @return si se ha podido o no
	 * @throws StackException excepcion de pila
	 */
	public boolean load(int pos) throws StackException {
		boolean ok = false;
		int n = readMem(pos);
		if (!mem.isEmpty(pos)) {
			ok = push(n);
		}else{
			new StackException("Memoria llena");
		}
		return ok;
	}

	/**
	 * salta el contador del programa a la instruccion N del goto
	 * 
	 * @param n
	 *            numero
	 * @return si se ha podido hacer el salto
	 */
	public boolean jump(int n) {
		if (n < bcProgram.getMarco()) {
			programCounter = n;
			return true;
		} else
			return false;
	}

	/**
	 * Suma 1 al contador
	 */
	public void next() {
		programCounter++;
	}

	/**
	 * pila vacia
	 * 
	 * @return si esta vacia true
	 */
	public boolean emptyStack() {
		return pila.isEmpty();
	}

	/**
	 * Escribe en la pos de mem un valor
	 * 
	 * @param pos
	 *            posicion
	 * @param value
	 *            valor
	 * @return si se ha podido escribir
	 * @throws StackException
	 */
	public boolean write(int pos) throws StackException {
		boolean ok = false;
		if (!pila.isEmpty()) {
			ok = mem.write(pos, pop());
		}
		return ok;
	}

	/**
	 * devuelve estado de la cpu la mem y la pila
	 */
	public String toString() {
		String estado = "Estado de la CPU: " + System.getProperty("line.separator");
		estado += "Memoria: " + mem.toString();
		estado += "Pila: " + pila.toString();
		estado += System.getProperty("line.separator");
		return estado;
	}

}
