package cpu;

import bytecodes.ByteCode;
import exceptions.ArrayException;
import instructions.Instruction;
import main.ByteCodeProgram;

public class Compiler {
	private ByteCodeProgram bytecode;
	private String[] varTable;
	private int numVars;
	final static int MAX_VAR = 26;

	/**
	 * Constructor de Compiler
	 */
	public Compiler() {
		this.bytecode = new ByteCodeProgram();
		this.varTable = new String[MAX_VAR];
		this.numVars = 0;
	}

	/**
	 * Genera los bytecode de las instrucciones
	 * @param pProgram instrucciones
	 * @return bytecode
	 */
	public ByteCodeProgram compile(ParseredProgram pProgram) {// throws...
		try {
			int i = 0;
			while (i < pProgram.getNumeroInstrucciones()) {
				Instruction instr = pProgram.getInstruction(i);
				instr.compile(this);
				i++;
			}
		} catch (ArrayException e) {
			 //new ArrayException("Error a la hora de extraer instrucciones");
			new ArrayException (e.getMessage());
		}

		return bytecode;
	}

	/**
	 * Devuelve el numero del marco
	 * @return marco
	 */
	public int getCurrentNumberOfByteCodes() {
		return bytecode.getMarco();
	}

	/**
	 * a�ade un bytecode
	 * @param byteCode bytecode
	 * @throws ArrayException excepcion de array
	 */
	public void insertarByteCode(ByteCode byteCode) throws ArrayException {
		this.bytecode.a�adirByteCode(byteCode);
	}

	/**
	 * Devuelve la pos de la tabla de variables en la que se encuentra var
	 * @param var variable
	 * @return pos
	 */
	public int indice(String var) {
		for (int i = 0; i < this.numVars; i++) {
			if (varTable[i].equals(var))
				return i;
		}
		return insertVar(var);
	}

	/**
	 * Inserta la variable en la tabla de variables
	 * @param var variable a insertar
	 * @return numero de variables
	 */
	public int insertVar(String var) {
		this.varTable[numVars] = var;
		this.numVars++;
		return numVars - 1;

	}
	/**
	 * Vac�a el array de varTable y pone el numVars a 0
	 */
	public void vaciarArray() {
		for (int i = 0; i < numVars; i++) {
			varTable[i] = null;
		}
		numVars = 0;
	}
}
