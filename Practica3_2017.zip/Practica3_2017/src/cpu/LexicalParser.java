package cpu;

import exceptions.ArrayException;
import exceptions.LexicalAnalysisException;
import instructions.Instruction;
import instructions.InstructionParser;
import main.SourceProgram;

public class LexicalParser {
	private SourceProgram sProgram;
	private int programCounter;

	/**
	 * Constructor con contador inicial a 0
	 */
	public LexicalParser() {
		programCounter = 0;
	}

	/**
	 * Va a�adiendo las instrucciones teniendo en cuenta los bucles
	 * 
	 * @param pProgram
	 *            instrucciones
	 * @param StopKey
	 *            valor de parada
	 * @throws ArrayException
	 *             excepcion de array
	 * @throws LexicalAnalysisException
	 *             excepcion lexica
	 */
	public void lexicalParser(ParseredProgram pProgram, String StopKey)
			throws ArrayException, LexicalAnalysisException {

		boolean stop = false;
		while (this.programCounter < sProgram.getMarcoSProgram() && !stop) {
			String instr = sProgram.devolverInstr(this.programCounter);
			if (instr.equalsIgnoreCase(StopKey)) {
				stop = true;
			} else {

				Instruction instruction = InstructionParser.parse(
						instr.split(" "), this);
				if (instruction == null) {
					throw new LexicalAnalysisException(
							"Excepcion: Error en el analisis lexico de la instruccion "
									+ instr + ".");
				} else {
					pProgram.a�adirInstr(instruction);
					programCounter++;
				}
			}
		}

		/*
		 * boolean stop = false; try { while (this.programCounter <
		 * sProgram.getMarcoSProgram() && !stop) {
		 * 
		 * String instr = sProgram.devolverInstr(this.programCounter); if
		 * (instr.equalsIgnoreCase(StopKey)) { stop = true; } else { Instruction
		 * instruction = InstructionParser.parse(instr.split(" "), this);
		 * pProgram.a�adirInstr(instruction); programCounter++; } } } catch
		 * (ArrayException e) { System.out.println(
		 * "Limite de instrucciones de programa parseado alcanzado"); } finally
		 * { if (!stop) throw new
		 * LexicalAnalysisException("Instruccion de cierre no encontrada"); }
		 */
	}
	/**
	 * Vac�a el array de sPrograms y pone el marco a 0
	 */
	public void reinCont(){
		programCounter = 0;
	}
	/**
	 * Inicializa el sourceProgram
	 * 
	 * @param sProgram
	 *            sourceProgram
	 */
	public void inicializarSProgram(SourceProgram sProgram) {
		this.sProgram = sProgram;
	}

	/**
	 * Incrementa el contador de programa
	 */
	public void increaseProgramCounter() {
		this.programCounter++;
	}
}
