package instructions.conditional;

import cpu.Compiler;
import cpu.LexicalParser;
import cpu.ParseredProgram;
import exceptions.ArrayException;
import exceptions.LexicalAnalysisException;
import instructions.Instruction;

public class Ifthen implements Instruction {
	private Condition condition;
	private ParseredProgram body;

	/**
	 * Constructor vacio
	 */
	public Ifthen() {

	}

	/**
	 * Constructor 
	 * @param cd condicion
	 * @param b cuerpo
	 */
	public Ifthen(Condition cd, ParseredProgram b) {
		this.condition = cd;
		this.body = b;
	}

	/**
	 * Crea la instruccion ifThen
	 */
	@Override
	public Instruction lexParse(String[] words, LexicalParser lexparser) throws ArrayException {
		Instruction inst = null;
		Condition cond = null;
		ParseredProgram wbody = new ParseredProgram();
		try {
			if ((words.length == 4) && (words[0].equals("if"))) {
				cond = ConditionParser.parse(words[1], words[2], words[3], lexparser);

				lexparser.increaseProgramCounter();
				lexparser.lexicalParser(wbody, "ENDIF");

				inst = new Ifthen(cond, wbody);
			}
		} catch (LexicalAnalysisException e) {
			return null;
		}
		return inst;
	}

	/**
	 * Genera los bytecode necesarios e inicializa el salto
	 */
	@Override
	public void compile(Compiler compiler) throws ArrayException {
		this.condition.compile(compiler);
		compiler.compile(this.body);
		int jump = compiler.getCurrentNumberOfByteCodes();
		this.condition.setJump(jump);
	}

	/**
	 * muestra string
	 */
	public String toString() {
		return new String("if " + condition.toString());
	}
}
