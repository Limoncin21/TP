package instructions.conditional;

import cpu.LexicalParser;

public class ConditionParser {
	private final static Condition[] condition = { new Equal(), new Less(), new LessEq(), new NotEqual() };

	/**
	 * Parsea la condicion y comprueba si es correcta
	 * @param string string 1
	 * @param string2 string 2
	 * @param string3 string 3
	 * @param lexparser lexicalParser
	 * @return condition
	 */
	public static Condition parse(String string, String string2, String string3, LexicalParser lexparser) {
		Condition cond = null;
		for (int i = 0; i < condition.length; i++) {
			cond = condition[i].parse(string, string2, string3, lexparser);
			if (cond != null)
				return cond;
		}
		return null;
	}
}
