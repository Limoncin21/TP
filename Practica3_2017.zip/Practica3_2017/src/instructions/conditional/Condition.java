package instructions.conditional;

import bytecodes.oneparameter.conditionaljumps.ConditionalJump;
import cpu.Compiler;
import cpu.LexicalParser;
import exceptions.ArrayException;
import instructions.assignments.Term;
import instructions.assignments.TermParser;

public abstract class Condition {
	private Term term1;
	private Term term2;
	private ConditionalJump condition;

	/**
	 * Constructor vacio
	 */
	public Condition() {

	}

	/**
	 * Constructor 
	 * @param term1 termino1
	 * @param term2 termino2
	 * @param cond condicion
	 */
	public Condition(Term term1, Term term2, ConditionalJump cond) {
		this.term1 = term1;
		this.term2 = term2;
		this.condition = cond;
	}

	/**
	 * Parsea la condicion
	 * @param t1 termino1
	 * @param op operacion
	 * @param t2 termino2
	 * @param parser lexicalparser
	 * @return condicion
	 */
	public Condition parse(String t1, String op, String t2, LexicalParser parser) {
		term1 = TermParser.parse(t1);
		term2 = TermParser.parse(t2);
		return this.parseOP(term1, op, term2, this.compileOP());

	}

	/**
	 * Metodo abstracto
	 * @param t1 termino1
	 * @param op operando
	 * @param t2 termino2
	 * @param cond condicion
	 * @return condicion
	 */
	public abstract Condition parseOP(Term t1, String op, Term t2, ConditionalJump cond);

	/**
	 * Genera el bytecode de los terminos, vuelca la condicion y genera el bytecode de esta
	 * @param compiler
	 * @throws ArrayException
	 */
	public void compile(Compiler compiler) throws ArrayException {
		compiler.insertarByteCode(term1.compile(compiler));
		compiler.insertarByteCode(term2.compile(compiler));
		this.condition = this.compileOP();
		compiler.insertarByteCode(this.condition);
	}

	/**
	 * metodo abstracto
	 * @return ConditionalJump
	 */
	protected abstract ConditionalJump compileOP();

	/**
	 * Vuelca el salto
	 * @param jump salto
	 */
	public void setJump(int jump) {
		condition.setSalto(jump);
	}

	/**
	 * Muestra string
	 */
	public String toString() {
		return new String(term1 + " " + condition + " " + term2);
	}
}
