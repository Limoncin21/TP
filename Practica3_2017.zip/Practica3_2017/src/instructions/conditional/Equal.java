package instructions.conditional;

import bytecodes.oneparameter.conditionaljumps.ConditionalJump;
import bytecodes.oneparameter.conditionaljumps.IfEq;
import instructions.assignments.Term;

public class Equal extends Condition {
	
	/**
	 * Constructor vacio
	 */
	public Equal() {

	}

	/**
	 * Constructor 
	 * @param term1 termino1
	 * @param term2 termino2
	 * @param condition condicion
	 */
	public Equal(Term term1, Term term2, ConditionalJump condition) {
		super(term1, term2, condition);
	}

	/**
	 * Crea un ifEq
	 */
	@Override
	protected ConditionalJump compileOP() {
		return new IfEq(0);
	}

	/**
	 * Comprueba que operando sea =
	 */
	@Override
	public Condition parseOP(Term t1, String op, Term t2, ConditionalJump cond) {
		if (op.equals("="))
			return new Equal(t1, t2, cond);
		else
			return null;
	}

}
