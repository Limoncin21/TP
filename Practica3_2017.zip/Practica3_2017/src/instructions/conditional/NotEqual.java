package instructions.conditional;

import instructions.assignments.Term;
import bytecodes.oneparameter.conditionaljumps.ConditionalJump;
import bytecodes.oneparameter.conditionaljumps.IfNeq;

public class NotEqual extends Condition {
	
	/**
	 * Constructor vacio
	 */
	public NotEqual() {

	}

	/**
	 * Constructor
	 * @param term1 termino
	 * @param term2 termino
	 * @param condition condicion
	 */
	public NotEqual(Term term1, Term term2, ConditionalJump condition) {
		super(term1, term2, condition);
	}

	/**
	 * Genera IfNeq
	 */
	@Override
	protected ConditionalJump compileOP() {
		return new IfNeq(0);
	}

	/**
	 * Comprueba si el signo es !=
	 */
	@Override
	public Condition parseOP(Term t1, String op, Term t2, ConditionalJump cond) {
		if (op.equals("!="))
			return new NotEqual(t1, t2, cond);
		else
			return null;
	}

}
