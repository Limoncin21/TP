package instructions.conditional;

import cpu.LexicalParser;
import cpu.ParseredProgram;
import exceptions.ArrayException;
import exceptions.LexicalAnalysisException;
import instructions.Instruction;
import bytecodes.oneparameter.Goto;
import cpu.Compiler;

public class While implements Instruction {
	private Condition condition;
	private ParseredProgram whileBody;

	/**
	 * Constructor vacio
	 */
	public While() {

	}

	/**
	 * Constructor
	 * @param cd condicion
	 * @param wB cuerpo
	 */
	public While(Condition cd, ParseredProgram wB) {
		this.condition = cd;
		this.whileBody = wB;
	}

	/**
	 * Genera el While 
	 */
	@Override
	public Instruction lexParse(String[] words, LexicalParser lexparser) throws ArrayException {
		Instruction inst = null;
		Condition cond = null;
		ParseredProgram wbody = new ParseredProgram();
		try {
			if ((words.length == 4) && (words[0].equals("while"))) {
				cond = ConditionParser.parse(words[1], words[2], words[3], lexparser);
				lexparser.increaseProgramCounter();
				lexparser.lexicalParser(wbody, "ENDWHILE");
				inst = new While(cond, wbody);
			}
		} catch (LexicalAnalysisException e) {
			return null;
		}

		return inst;

	}

	/**
	 * genera los bytecode necesarios
	 */
	@Override
	public void compile(Compiler compiler) throws ArrayException {
		int num = compiler.getCurrentNumberOfByteCodes();
		this.condition.compile(compiler);
		compiler.compile(this.whileBody);
		int jump = compiler.getCurrentNumberOfByteCodes();
		this.condition.setJump(jump + 1);
		compiler.insertarByteCode(new Goto(num));
	}

	/**
	 * Muestra string
	 */
	public String toString() {
		return new String("While " + condition.toString());
	}
}
