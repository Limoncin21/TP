package instructions.conditional;

import instructions.assignments.Term;
import bytecodes.oneparameter.conditionaljumps.ConditionalJump;
import bytecodes.oneparameter.conditionaljumps.IfLeq;

public class LessEq extends Condition {
	/**
	 * Constructor vacio
	 */
	public LessEq() {

	}

	/**
	 * Constructor
	 * @param term1 termino
	 * @param term2 termino
	 * @param condition condicion
	 */
	public LessEq(Term term1, Term term2, ConditionalJump condition) {
		super(term1, term2, condition);
	}

	/**
	 * genera el ifLeq
	 */
	@Override
	protected ConditionalJump compileOP() {
		return new IfLeq(0);
	}

	/**
	 * Comprueba que cond es <=
	 */
	@Override
	public Condition parseOP(Term t1, String op, Term t2, ConditionalJump cond) {
		if (op.equals("<="))
			return new LessEq(t1, t2, cond);
		else
			return null;
	}

}
