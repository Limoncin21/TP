package instructions.conditional;

import instructions.assignments.Term;
import bytecodes.oneparameter.conditionaljumps.ConditionalJump;
import bytecodes.oneparameter.conditionaljumps.IfLe;

public class Less extends Condition {
	/**
	 * Constructor vacio
	 */
	public Less() {

	}

	/**
	 * Constructor
	 * @param term1 term
	 * @param term2 term
	 * @param condition condicion
	 */
	public Less(Term term1, Term term2, ConditionalJump condition) {
		super(term1, term2, condition);
	}

	/**
	 * Genera el ifLE
	 */
	@Override
	protected ConditionalJump compileOP() {
		return new IfLe(0);
	}

	/**
	 * Cmprueba que la condicion sea <
	 */
	@Override
	public Condition parseOP(Term t1, String op, Term t2, ConditionalJump cond) {
		if (op.equals("<"))
			return new Less(t1, t2, cond);
		else
			return null;

	}

}
