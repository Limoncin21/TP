package instructions;

import cpu.Compiler;
import cpu.LexicalParser;
import exceptions.ArrayException;

public interface Instruction {
	/**
	 * metodo abstracto
	 * @param string cadena
	 * @param lexparser lexicalParser
	 * @return instruccion
	 * @throws ArrayException array excepcion
	 */
	Instruction lexParse(String[] string, LexicalParser lexparser) throws ArrayException;

	/**
	 * Genera bytecode
	 * @param compiler Compiler
	 * @throws ArrayException excepcion de array
	 */
	void compile(Compiler compiler) throws ArrayException;
}
