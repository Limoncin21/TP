package instructions;

import cpu.LexicalParser;
import exceptions.ArrayException;
import bytecodes.Out;
import bytecodes.oneparameter.Load;
import cpu.Compiler;

public class Write implements Instruction {
	private String varName;

	/**
	 * Constructor vacio
	 */
	public Write() {

	}

	/**
	 * Constructor con parametros
	 * @param var nombre de variable
	 */
	public Write(String var) {
		this.varName = var;
	}

	/**
	 * Parsea una instruccion, comprueba si es correcta y si es asi la crea
	 */
	@Override
	public Instruction lexParse(String[] words, LexicalParser lexparser) {
		if (words[0].equals("write") && 'a' <= words[1].charAt(0) && words[1].charAt(0) <= 'z') {
			this.varName = words[1];
			return new Write(varName);
		} else
			return null;
	}

	/**
	 * Genera los bytecode necesarios para un write
	 */
	@Override
	public void compile(Compiler compiler) throws ArrayException {
		int index = compiler.indice(this.varName);
		compiler.insertarByteCode(new Load(index));
		compiler.insertarByteCode(new Out());
	}

	/**
	 * Devuelve el string de write
	 */
	public String toString() {
		return new String("Write " + varName);
	}
}
