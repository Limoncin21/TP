package instructions;

import cpu.LexicalParser;
import exceptions.ArrayException;
import instructions.assignments.CompoundAssignment;
import instructions.assignments.SimpleAssignment;
import instructions.conditional.*;

public class InstructionParser {
	private final static Instruction[] instruction = { new Return(), new Write(), new SimpleAssignment(),
			new CompoundAssignment(), new Ifthen(), new While() };

	/**
	 * Parsea las instrucciones
	 * @param string cadena
	 * @param lexParser lexicalParser
	 * @return la instruccion parseada
	 * @throws ArrayException excepcion de array
	 */
	public static Instruction parse(String[] string, LexicalParser lexParser) throws ArrayException {
		Instruction ins = null;
		for (int i = 0; i < instruction.length; i++) {
			ins = instruction[i].lexParse(string, lexParser);
			if (ins != null)
				return ins;
		}
		return null;
	}
}
