package instructions.assignments;

import bytecodes.oneparameter.Store;
import cpu.Compiler;
import cpu.LexicalParser;
import exceptions.ArrayException;
import instructions.Instruction;

public class SimpleAssignment implements Instruction {
	private String var_name;
	private Term rhs;

	/**
	 * Constructor vacio
	 */
	public SimpleAssignment() {

	}

	/**
	 * Constructor
	 * @param var variable
	 * @param term termino
	 */
	public SimpleAssignment(String var, Term term) {
		this.var_name = var;
		this.rhs = term;
	}

	/**
	 * Comprueba si es una asignacion simple y de ser asi la crea
	 */
	@Override
	public Instruction lexParse(String[] words, LexicalParser lexparser) {
		if ((words.length != 3) && ('a' <= words[0].charAt(0) && words[0].charAt(0) <= 'z') & (words[1] != "=")) {
			return null;
		} else {
			var_name = words[0];
			rhs = TermParser.parse(words[2]);
			return new SimpleAssignment(var_name, rhs);
		}
	}

	/**
	 * Genera los byteCode necesarios para realizar una asignacion simple
	 */
	@Override
	public void compile(Compiler compiler) throws ArrayException {
		compiler.insertarByteCode(rhs.compile(compiler));
		int num = compiler.indice(var_name);
		compiler.insertarByteCode(new Store(num));
	}

	/**
	 * Muestra el string
	 */
	public String toString() {
		return new String(var_name + " = " + rhs);
	}

}
