package instructions.assignments;

import cpu.LexicalParser;
import exceptions.ArrayException;
import instructions.Instruction;
import bytecodes.arithmetics.Add;
import bytecodes.arithmetics.Div;
import bytecodes.arithmetics.Mul;
import bytecodes.arithmetics.Sub;
import bytecodes.oneparameter.Store;
import cpu.Compiler;

public class CompoundAssignment implements Instruction {
	private String var_name;
	private String operator;
	private Term term1;
	private Term term2;

	/**
	 * Constructor vacio
	 */
	public CompoundAssignment() {

	}

	/**
	 * Constructor con parametros
	 * @param var variable
	 * @param term1 termino1
	 * @param op operando
	 * @param term2 termino2
	 */
	public CompoundAssignment(String var, Term term1, String op, Term term2) {
		this.var_name = var;
		this.operator = op;
		this.term1 = term1;
		this.term2 = term2;
	}

	/**
	 * Comprueba si es una instrccion correcta y de ser asi la crea
	 */
	@Override
	public Instruction lexParse(String[] words, LexicalParser lexparser) {
		if ((words.length != 5) && ('a' <= words[0].charAt(0) && words[0].charAt(0) <= 'z') && (words[1] != null)) {
			return null;
		} else {
			var_name = words[0];
			term1 = TermParser.parse(words[2]);
			operator = words[3];
			term2 = TermParser.parse(words[4]);
			return new CompoundAssignment(var_name, term1, operator, term2);
		}
	}

	/**
	 * Genera el bytecode para los dos terminos, luego el necesario para la operacion y el store
	 */
	@Override
	public void compile(Compiler compiler) throws ArrayException {
		compiler.insertarByteCode(term1.compile(compiler));
		compiler.insertarByteCode(term2.compile(compiler));
		if (operator.charAt(0) == '+') {
			compiler.insertarByteCode(new Add());
		} else if (operator.charAt(0) == '-') {
			compiler.insertarByteCode(new Sub());
		} else if (operator.charAt(0) == '*') {
			compiler.insertarByteCode(new Mul());
		} else if (operator.charAt(0) == '/') {
			compiler.insertarByteCode(new Div());
		}
		compiler.insertarByteCode(new Store(compiler.indice(var_name)));
	}

	/**
	 * string de compoundAssignment
	 */
	public String toString() {
		return new String(var_name + " = " + term1 + " " + operator + " " + term2);
	}
}
