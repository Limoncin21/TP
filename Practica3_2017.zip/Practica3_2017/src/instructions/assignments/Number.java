package instructions.assignments;

import bytecodes.ByteCode;
import bytecodes.oneparameter.Push;
import cpu.Compiler;

public class Number implements Term {
	private int num;

	/**
	 * Constructor
	 * @param term termino
	 */
	public Number(int term) {
		this.num = term;
	}

	/**
	 * Constructor vacio
	 */
	public Number() {

	}

	/**
	 * Comprueba si es un entero
	 */
	public Term parse(String term) throws NumberFormatException {
		Term numero = null;
		try {
			this.num = Integer.parseInt(term);
			numero = new Number(Integer.parseInt(term));
		} catch (Exception e) {
			throw new NumberFormatException("No es un numero");
		}
		return numero;
	}

	/**
	 * Genera el push
	 */
	@Override
	public ByteCode compile(Compiler compiler) {
		return new Push(num);
	}
}
