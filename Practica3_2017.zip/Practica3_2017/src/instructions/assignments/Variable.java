package instructions.assignments;

import bytecodes.ByteCode;
import bytecodes.oneparameter.Load;
import cpu.Compiler;

public class Variable implements Term {
	private String var;

	/**
	 * Constructor
	 * @param term string
	 */
	public Variable(String term) {
		this.var = term;
	}

	/**
	 * Constructor vacio
	 */
	public Variable() {

	}

	/**
	 * Comprueba que es una letra es decir un termino
	 */
	public Term parse(String term) {
		if (term.length() != 1)
			return null;
		else {
			char name = term.charAt(0);
			if ('a' <= name && name <= 'z')
				return new Variable(term);
			else
				return null;
		}
	}

	/**
	 * Genera el load
	 */
	@Override
	public ByteCode compile(Compiler compiler) {
		return new Load(compiler.indice(var));
	}

	/**
	 * Muestra el string
	 */
	public String toString() {
		return new String(var);
	}
}
