package instructions.assignments;

import bytecodes.ByteCode;
import cpu.Compiler;

public interface Term {
	/**
	 * metodo abstracto
	 * @param term termino
	 * @return termino
	 */
	Term parse(String term);

	/**
	 * metodo abstracto
	 * @param compiler compiler
	 * @return bytecode
	 */
	ByteCode compile(Compiler compiler);
}
