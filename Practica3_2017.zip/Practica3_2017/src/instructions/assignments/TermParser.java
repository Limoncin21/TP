package instructions.assignments;

public class TermParser {

	private final static Term[] term = { new Variable(), new Number() };

	/**
	 * Parsea el termino
	 * @param string cadena
	 * @return termino si ha sido posible null en caso contrario
	 */
	public static Term parse(String string) {
		Term termino = null;
		for (int i = 0; i < term.length; i++) {
			termino = term[i].parse(string);
			if (termino != null)
				return termino;
		}
		return null;
	}
}
