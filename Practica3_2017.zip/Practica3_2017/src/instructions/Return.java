package instructions;

import cpu.LexicalParser;
import exceptions.ArrayException;
import bytecodes.Halt;
import cpu.Compiler;

public class Return implements Instruction {
	
	/**
	 * Constructor vacio
	 */
	public Return() {

	}

	/**
	 * Parsea para ver si es return
	 */
	@Override
	public Instruction lexParse(String[] words, LexicalParser lexparser) {
		if (words[0].equals("return"))
			return new Return();
		else
			return null;
	}

	/**
	 * Genera el bytecode de Halt y lo inserta
	 */
	@Override
	public void compile(Compiler compiler) throws ArrayException {
		compiler.insertarByteCode(new Halt());
	}

	/**
	 * String de return
	 */
	public String toString() {
		return new String("Return");
	}
}
