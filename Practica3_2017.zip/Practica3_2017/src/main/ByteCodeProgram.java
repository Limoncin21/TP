package main;

import bytecodes.ByteCode;
import exceptions.ArrayException;

public class ByteCodeProgram {
	private ByteCode[] program;// array byteCode
	private int marco;
	public static int MAX_INSTR = 50;

	/**
	 * Constructor Inicializa el progrma y pone el marco a 0
	 */
	public ByteCodeProgram() {
		inicializarProgram();
		marco = 0;
	}

	/**
	 * Crea el array de byteCode's
	 */
	public void inicializarProgram() {
		program = new ByteCode[MAX_INSTR];
	}

	/**
	 * Vac�a el array de byteCode's y pone el marco a 0
	 */
	public void vaciarArray() {
		for (int i = 0; i < marco; i++) {
			program[i] = null;
		}
		marco = 0;
	}

	/**
	 * A�ade un nuevo byteCode y aumenta el marco
	 * 
	 * @param byteCode
	 *            el byteCode
	 */
	public void a�adirByteCode(ByteCode byteCode) throws ArrayException {
		
		//No se redimensiona se lanza la excepcion
		
		if (marco == MAX_INSTR){
			throw new ArrayException("Excepcion: Limite de instrucciones ByteCode alcanzado");
			//MAX_INSTR = marco + 10;
			//this.redimensionar();
		}
		program[marco] = byteCode;
		marco++;
		
		/*
		if (marco == MAX_INSTR) {
			MAX_INSTR = marco + 10;
			this.redimensionar();
		}
		program[marco] = byteCode;
		marco++;
		*/
	}

	/**
	 * comprueba si se puede hacer replace
	 * 
	 * @param pos
	 *            posicion
	 * @param bytecode
	 *            bytecode
	 * @return se ha podido hacer replace correctamente (en caso afirmatiovo lo
	 *         reemplaza)
	 */
	public boolean replace(int pos, ByteCode bytecode) throws ArrayException {
		boolean ok = false;
		if (pos >= 0 && pos < marco && bytecode != null) {
			program[pos] = bytecode;
			ok = true;
		}
		return ok;
	}

	/**
	 * Devuelva la instrucci�n de la posici�n n
	 * 
	 * @param n
	 *            posici�n
	 * @return byteCode
	 */
	public ByteCode devolverInstruccion(int n) throws ArrayException {
		if (n >= 0 && n < MAX_INSTR && program[n] != null) {
			ByteCode byteCode = program[n];
			return byteCode;
		} else {
			return null;
		}
	}

	/**
	 * Devuelve el marco
	 * 
	 * @return marco
	 */
	public int getMarco() {
		return this.marco;
	}

	/**
	 * Devuelve todos las instrucciones de program(array de byteCode's)
	 */
	public String toString() {
		String cadena = "Programa almacenado:" + System.getProperty("line.separator");
		for (int i = 0; i < marco; i++) {
			cadena += i + ": " + program[i].toString() + System.getProperty("line.separator");
		}
		return cadena;
	}
}
