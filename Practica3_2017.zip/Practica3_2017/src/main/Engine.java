package main;

import java.util.Scanner;

import bytecodes.ByteCode;
import bytecodes.ByteCodeParser;
import commands.Command;
import commands.CommandParser;
import cpu.CPU;
import cpu.Compiler;
import cpu.LexicalParser;
import cpu.ParseredProgram;
import exceptions.ArrayException;
import exceptions.BadFormatByteCode;
import exceptions.ExecutionError;
import exceptions.LexicalAnalysisException;

import java.io.File;
import java.io.FileNotFoundException;

public class Engine {
	private ByteCodeProgram program;// representa el programa actual
	private SourceProgram sProgram; // se almacena el programa fuente que se
									// carga de fichero
	private ParseredProgram parseredProgram;// se almacena el programa parseado
											// una vez realizado el analisis
											// lexico
	private LexicalParser lexicalParser;
	private Compiler compiler;
	private boolean end;// controla el final del bucle de ejecuccion
	private static Scanner in;// entrada por teclado
	private CPU cpu;

	/**
	 * Constructor
	 * 
	 * @param in
	 *            scanner
	 */
	@SuppressWarnings("static-access")
	public Engine(Scanner in) {
		this.in = in;
		this.program = new ByteCodeProgram();
		this.sProgram = new SourceProgram();
		this.parseredProgram = new ParseredProgram();
		this.lexicalParser = new LexicalParser();
		this.compiler = new Compiler();
		this.cpu = new CPU(this.program);
		this.end = false;
	}

	/**
	 * Comienza con la ejecucion del programa
	 * @throws BadFormatByteCode 
	 */
	public void start() throws BadFormatByteCode {
				try {
					while (!end) {
						Command command;
						command = CommandParser.parse(pedirComandos());
						if (command == null) {
							System.out.println("Error: Ejecucion incorrecta del comando");
						} else {
							System.out.println(
									"Comienza la ejecucion de " + command.toString() + System.getProperty("line.separator"));
							boolean ex;
							ex = command.execute(this);
							if (ex) {
								System.out.println(this.sProgram);
								System.out.println(this.program);
							}
						}
					}
					System.out.println("Fin de la ejecucion...");
			
				}	catch(LexicalAnalysisException e){
					System.out.println("linea incorrecta");
					this.start();
				}
				catch(ArrayException e){
					System.out.println(e.toString());
					this.start();
				}
				catch(ExecutionError e){
					System.out.println(e.toString());
					this.start();
				} catch (FileNotFoundException e) {
					System.out.println(e.toString());
					this.start();
				}
	}

	/**
	 * Pide la instrucci�n al completo
	 * 
	 * @return la instrucci�n
	 */
	private String pedirComandos() {
		System.out.print(">");
		String line = in.nextLine();
		return line;
	}
	
	/**
	 * Genera los bytecode
	 * @throws ArrayException excepcion de array
	 * @throws LexicalAnalysisException excepcion lexica
	 */
	public void compile() throws ArrayException, LexicalAnalysisException {
		try{
		this.lexicalAnalysis();
		this.generateByteCode();
		}catch (LexicalAnalysisException e){
			throw new LexicalAnalysisException("Fallo en el parseo lexico");
		}
	}

	/**
	 * Inicializa el sProgram y realiza el lexicalParser
	 * @throws LexicalAnalysisException excepcion lexica
	 * @throws LexicalAnalysisException excepcion lexica
	 * @throws ArrayException excepcion de array
	 */
	private void lexicalAnalysis() throws LexicalAnalysisException, LexicalAnalysisException, ArrayException {
		lexicalParser.inicializarSProgram(sProgram);
	 	lexicalParser.lexicalParser(parseredProgram, "END");
	}

	/**
	 * Genera los bytecode
	 * @throws ArrayException excepcion de array
	 */
	private void generateByteCode()throws ArrayException{
		this.program = this.compiler.compile(parseredProgram);
	}

	/**
	 * ejecuta la carga de fichero
	 * @param fichName nombre de fichero
	 * @throws FileNotFoundException excepcion de archivo no encontrado
	 * @throws ArrayException excepcion de array
	 */
	public void executeLoad(String fichName) throws FileNotFoundException, ArrayException {
		reset();
		Scanner sc = new Scanner(new File(fichName));
		 try {
		while (sc.hasNextLine()) {
			String instruction = sc.nextLine();
			this.sProgram.addInstruction(instruction);

		}
		}
		 finally {
		sc.close();

		 }
	}
	public void reset() {
		program.vaciarArray();
		sProgram.vaciarArray();
		parseredProgram.vaciarArray();
		compiler.vaciarArray();
		lexicalParser.reinCont();
		cpu.reset();
	}
	/**
	 * Ejecuta help
	 * 
	 * @return true
	 */
	public boolean executeHELP() {
		boolean ok = false;
		if (showHelp()) {
			ok = true;
		}
		return ok;
	}

	/**
	 * Ejecuta quit
	 * 
	 * @return true
	 */
	public boolean executeQUIT() {
		boolean ok = false;
		if (endExecution()) {
			ok = true;
		}
		return ok;
	}

	/**
	 * Ejecuta el run
	 * 
	 * @return true si se ha iniciado el run
	 * @throws ExecutionError 
	 * @throws ArrayException 
	 */
	public boolean executeRUN() throws ExecutionError, ArrayException {
		boolean ok = false;
		if (startExecution()) {
			ok = true;
		}
		return ok;
	}

	/**
	 * Ejecuta el replace
	 * 
	 * @param replace
	 *            posicion a reemplazar
	 * @return true si se ha reemplazado
	 * @throws ArrayException 
	 * @throws BadFormatByteCode 
	 */
	public boolean executeREPLACE(int replace) throws ArrayException, BadFormatByteCode {
		
		this.cpu = new CPU(this.program);
		cpu.reset();
		boolean ok = false;
   		if (replace <= program.getMarco() && replace >= 0) {
			System.out.print("Nueva instruccion: ");
			String line = in.nextLine().toUpperCase();
			String[] cadena = line.split(" ");
			ByteCode bytecode = ByteCodeParser.parse(cadena);
			ok = this.program.replace(replace, bytecode);
		}
   		if (!ok)
   			throw new BadFormatByteCode("ByteCode introducido incorrecto");
		return ok;
	}

	/**
	 * Empieza la ejecuci�n de la CPU
	 * 
	 * @return true
	 * @throws ExecutionError 
	 * @throws ArrayException 
	 */
	public boolean startExecution() throws ExecutionError, ArrayException {
		this.cpu = new CPU(this.program);
		boolean parada;
		parada = cpu.run();
		if (parada) {
			System.out.println(
					"El estado de la maquina tras ejecutar el programa es: " + System.getProperty("line.separator"));
			System.out.println(this.cpu);
		}
		return parada;
	}

	/**
	 * Muestra el men� de ayuda
	 * 
	 * @return true
	 */
	public boolean showHelp() {
		CommandParser.showHelp();
		return true;
	}

	/**
	 * Termina la ejecuci�n
	 * 
	 * @return true;
	 */
	public boolean endExecution() {
		end = true;
		return true;

	}
}
