package main;

import java.util.Scanner;

import exceptions.BadFormatByteCode;

public class Main {
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		Engine engine = new Engine(in);
		try {
			engine.start();
		} catch (BadFormatByteCode e) {
			e.printStackTrace();
		}

	}
}
