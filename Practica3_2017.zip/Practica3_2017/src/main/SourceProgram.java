package main;

import exceptions.ArrayException;

public class SourceProgram {
	private String[] sProgram;// array byteCode
	private int marco;
	public static int MAX_INSTR = 20;

	/**
	 * Constructor Inicializa el programa y pone el marco a 0
	 */
	public SourceProgram() {
		inicializarSProgram();
		marco = 0;
	}

	/**
	 * a�ade una instrccion
	 * @param instr instruccion
	 * @throws ArrayException excepcion de array
	 */
	public void addInstruction(String instr)throws ArrayException {
		
		//si esta lleno se lanza excepcion no se redimensiona
		
		/*if (marco > MAX_INSTR){
			throw new ArrayException("Excepcion: Limite de instrucciones alcanzado.");
		}
		else{
			sProgram[marco] = instr;
			marco++;
		}*/
		
		
		if (marco >= MAX_INSTR) {
			MAX_INSTR = marco + 100;
			redimensionar();
		}
		sProgram[marco] = instr;
		marco++;
	}

	/**
	 * redimensiona con mas 1/2 
	 */
	private void redimensionar() {
		int newDim = MAX_INSTR + MAX_INSTR / 2;
		String[] newSProgram = new String[newDim];
		for (int i = 0; i < newDim; i++) {
			if (i < marco) {
				newSProgram[i] = this.sProgram[i];
			} else {
				newSProgram[i] = null;
			}
		}
		this.sProgram = newSProgram;
		MAX_INSTR = newDim;
	}

	/**
	 * Crea el array de sPrograms
	 */
	public void inicializarSProgram() {
		sProgram = new String[MAX_INSTR];
	}

	/**
	 * Devuelve el marco
	 * @return marco
	 */
	public int getMarcoSProgram() {
		return marco;
	}

	/**
	 * DEvuelve instruccion
	 * @param pos posicion
	 * @return string
	 */
	public String pidesInstr(int pos) {
		return sProgram[pos];
	}

	/**
	 * Devuelve la instruccion
	 * @param cuenta int
	 * @return string
	 */
	public String devolverInstr(int cuenta) {
		return sProgram[cuenta];
	}

	/**
	 * Vac�a el array de sPrograms y pone el marco a 0
	 */
	public void vaciarArray() {
		for (int i = 0; i < marco; i++) {
			sProgram[i] = null;
		}
		marco = 0;
	}

	/**
	 * Muestra el programa almacenado
	 */
	public String toString() {
		String cadena = "Programa fuente almacenado:" + System.getProperty("line.separator");
		for (int i = 0; i < marco; i++) {
			cadena += i + ": " + sProgram[i].toString() + System.getProperty("line.separator");
		}
		return cadena;
	}
}
