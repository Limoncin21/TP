package bytecodes;

import cpu.CPU;
import exceptions.ExecutionError;

public class Out extends ByteCode {

	/**
	 * ejecuta Out
	 * @throws ExecutionError 
	 */
	@Override
	public boolean execute(CPU cpu) throws ExecutionError {
		
		if (cpu.out()){
			cpu.next();
			return true;
		}
		else{
			throw new ExecutionError("Excepcion-bytecode " + this.toString() + ": Error de ejecucion.");
		}
		/*
		cpu.next();
		return cpu.out();
		*/
	}

	/**
	 * Comprueba si es OUT
	 */
	@Override
	public ByteCode parse(String[] s) {
		if (s[0] == "OUT") {
			return new Out();
		} else
			return null;
	}

	/**
	 * Devuelve OUT
	 */
	public String toString() {
		return new String("OUT");
	}

}
