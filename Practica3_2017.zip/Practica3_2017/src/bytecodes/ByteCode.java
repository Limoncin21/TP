package bytecodes;

import cpu.CPU;
import exceptions.DivisionByZero;
import exceptions.ExecutionError;
import exceptions.StackException;

public abstract class ByteCode {
	/**
	 * metodo abstracto
	 * @param cpu cpu
	 * @return si se ha ejecutado o no
	 * @throws DivisionByZero 
	 * @throws StackException 
	 * @throws ExecutionError 
	 */
	abstract public boolean execute(CPU cpu) throws DivisionByZero, StackException, ExecutionError;
	
	/**
	 * metodo abstracto
	 * @param s cadena de string
	 * @return bytecode 
	 */
	abstract public ByteCode parse(String[] s);
}
