package bytecodes.oneparameter;

import bytecodes.ByteCode;
import cpu.CPU;
import exceptions.StackException;

public class Push extends ByteCodesOneParameter{
	private int n;
	
	/**
	 * const
	 * @param n numero
	 */
	public Push(int n){
		this.n = n;
	}
	
	/**
	 * comprueba que sea la inst push y la crea sino null
	 */
	@Override
	protected ByteCode parseOneParameter(String[] s) {
		
		ByteCode bytecode = null;
		if (s[0].equals("PUSH")){
			try {
				n = Integer.parseInt(s[1]);
				bytecode = new Push(n);
			}
			catch (NumberFormatException e){
				bytecode = null;
			}
		}
		return bytecode;
		/*
		if (s[0].equals("PUSH")){
			n = Integer.parseInt(s[1]);
			return new Push(n);
		}else
			return null;
			*/
	}
	
	/**
	 * ejecuta push
	 * @throws StackException 
	 */
	public boolean execute (CPU cpu) throws StackException{
		
		cpu.next();
		return cpu.push(n);
		
		/*
		cpu.next();
		try {
			return cpu.push(n);
		} catch (StackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		*/
	}
	
	/**
	 * devuelve push n
	 */
	public String toString(){
		return new String ("PUSH " + n);
	}
}
