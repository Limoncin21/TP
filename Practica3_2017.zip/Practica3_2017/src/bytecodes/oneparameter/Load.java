package bytecodes.oneparameter;

import bytecodes.ByteCode;
import cpu.CPU;
import exceptions.StackException;

public class Load extends ByteCodesOneParameter {
	private int n;
	
	/**
	 * constructor
	 * @param n numero
	 */
	public Load(int n) {
		this.n = n;
	}

	/**
	 * comprueba que sea la inst load y la crea sino null
	 */
	@Override
	protected ByteCode parseOneParameter(String[] s) {
		
		ByteCode bytecode = null;
		if (s[0].equals("LOAD")){
			try {
				n = Integer.parseInt(s[1]);
				bytecode = new Load(n);
			}
			catch (NumberFormatException e){
				bytecode = null;
			}
		}
		return bytecode;
		
		/*
		if (s[0].equals("LOAD")){
			n = Integer.parseInt(s[1]);
			return new Load(n);
		}else
			return null;
			*/
	}

	/**
	 * ejecuta load
	 * @throws StackException 
	 */
	public boolean execute(CPU cpu) throws StackException {
		
		//cntrolamos la exceocion de que el load este bien en parse
		cpu.next();
		return cpu.load(n);
		/*
		cpu.next();
		try {
			return cpu.load(n);
		} catch (StackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		*/
	}

	/**
	 * devuelve load n
	 */
	public String toString() {
		return new String ("LOAD " + n);
	}
}
