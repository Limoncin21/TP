package bytecodes.oneparameter;

import bytecodes.ByteCode;
import cpu.CPU;
import exceptions.ExecutionError;
import exceptions.StackException;

public class Store extends ByteCodesOneParameter{
	private int n;
	
	/**
	 * const
	 * @param n numero
	 */
	public Store(int n){
		this.n = n;
	}
	
	/**
	 * comprueba que sea la inst store y la crea sino null
	 */
	@Override
	protected ByteCode parseOneParameter(String[] s) {
		
		ByteCode bytecode = null;
		if (s[0].equals("STORE")){
			try {
				n = Integer.parseInt(s[1]);
				bytecode = new Store(n);
			}
			catch (NumberFormatException e){
				bytecode = null;
			}
		}
		return bytecode;
		/*
		if (s[0].equals("STORE")){
			n = Integer.parseInt(s[1]);
			return new Store(n);
		}else
			return null;
			*/
	}
	
	/**
	 * ejecuta store
	 * @throws ExecutionError 
	 * @throws StackException 
	 */
	public boolean execute (CPU cpu) throws StackException, ExecutionError{
		
		//cpu.executeStore(param) = write?
		if (cpu.write(n)){
			cpu.next();
			return true;
		}
		else{
			throw new ExecutionError("Excepcion-bytecode " + this.toString() + ": Error de ejecucion.");
		}
		/*
		cpu.next();
		try {
			return cpu.write(n);
		} catch (StackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		*/
	}
	
	/**
	 * devuelve store n
	 */
	public String toString(){
		return new String ("STORE " + n);
	}

}
