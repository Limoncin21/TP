package bytecodes.oneparameter.conditionaljumps;

import bytecodes.ByteCode;
import cpu.CPU;
import exceptions.ExecutionError;

public abstract class ConditionalJump extends ByteCode {
	protected int n;

	/**
	 * const
	 * 
	 * @param n
	 *            numero
	 */
	public ConditionalJump(int n) {
		this.n = n;
	}

	/**
	 * ejecuta el salto condicional si se puede
	 * @throws ExecutionError 
	 */
	@Override
	public boolean execute(CPU cpu) throws ExecutionError {
		
		int cima, subCima;
		boolean ok = false;
		if (!cpu.emptyStack()) {
			cima = cpu.pop();
			if (!cpu.emptyStack()) {
				subCima = cpu.pop();
				if (!compares(cima, subCima, cpu)) {
					ok = cpu.jump(n);
				}
				else{
					cpu.next();
					ok = true;
				}
			}
			else{
				cpu.push(cima);
				throw new ExecutionError("Excepcion-bytecode " + this.toString() + ": Error de ejecucion.");
			}
		}
		else{
			throw new ExecutionError("Excepcion-bytecode " + this.toString() + ": Error de ejecucion.");
		}
		return ok;
		
		/*
		boolean ok = false;
		int cima, subCima;

		try {
			if (!cpu.emptyStack()) {
				cima = cpu.pop();
				if (!cpu.emptyStack()) {
					subCima = cpu.pop();
					if (!compares(cima, subCima, cpu)) {
						ok = cpu.jump(n);
					} else {
						cpu.next();
						ok = true;
					}

				} else {
					cpu.push(cima);
				}
			}
		} catch (StackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ok;
		*/
	}

	/**
	 * actualiza el valor del salto
	 * 
	 * @param jump
	 *            numero de inst a la que se quiere saltar
	 */
	public void setSalto(int jump) {
		this.n = jump;
	}

	/**
	 * metodo abstracto
	 * 
	 * @param c
	 *            cima
	 * @param sc
	 *            subcima
	 * @param cpu
	 *            cpu
	 * @return si se ha podido hacer
	 */
	protected abstract boolean compares(int c, int sc, CPU cpu);

}
