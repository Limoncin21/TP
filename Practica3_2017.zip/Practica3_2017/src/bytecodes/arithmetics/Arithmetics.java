package bytecodes.arithmetics;

import bytecodes.ByteCode;
import cpu.CPU;
import exceptions.DivisionByZero;
import exceptions.ExecutionError;
import exceptions.StackException;

public abstract class Arithmetics extends ByteCode {
	
	/**
	 * constructor vac�o
	 */
	public Arithmetics() {
	}
	
	/**
	 * Metodo abstracto para ver que instruccion aritmetica es mediante el parse
	 * @param s string
	 * @return bytecode de arithmetics 
	 */
	protected abstract ByteCode parseOperacion(String s);

	/**
	 * Metodo abstracto que realizara la operacion que le corresponda
	 * @param c cima
	 * @param sc subcima
	 * @param cpu cpu
	 * @return true si se ha realizado la operacion
	 * @throws DivisionByZero 
	 * @throws StackException 
	 */
	protected abstract boolean operacion(int c, int sc, CPU cpu) throws DivisionByZero, StackException;

	/**
	 * Ejecuta la operaci�n arithmetic adecuada
	 * @throws ExecutionError 
	 */
	@Override
	public boolean execute(CPU cpu) throws ExecutionError {
		int cima, subCima;
		boolean ok = false;
		if (!cpu.emptyStack()){
			cima = cpu.pop();
			if (!cpu.emptyStack()){
				subCima = cpu.pop();
				cpu.next();
				ok = this.operacion(cima, subCima, cpu);
			}else{
				cpu.push(cima);
				throw new ExecutionError("Excepcion-bytecode " + this.toString() + ": Error de ejecucion.");
			}
		}
		else{
			throw new ExecutionError("Excepcion-bytecode " + this.toString() + ": Error de ejecucion.");
		}
		return ok;
		
		/*
		boolean ok = false;
		int cima, subCima;
			try {
				if (!cpu.emptyStack()){
					cima = cpu.pop();
					if (!cpu.emptyStack()){
						subCima = cpu.pop();
						cpu.next();
						ok = this.operacion(cima, subCima, cpu);
					}else{
						cpu.push(cima);
					}
				}
			} catch (StackException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return ok;
		*/
	}

	/**
	 * compreuba que sea una inst aritmetica es decir que su long sea uno
	 */
	@Override
	public ByteCode parse(String[] s) {
		if (s.length == 1)
			return this.parseOperacion(s[0]);
		else
			return null;
	}

}
