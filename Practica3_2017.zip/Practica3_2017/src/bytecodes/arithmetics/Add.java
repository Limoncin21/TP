package bytecodes.arithmetics;

import bytecodes.ByteCode;
import cpu.CPU;
import exceptions.StackException;

public class Add extends Arithmetics {

	/**
	 * operacion de suma
	 */
	protected boolean operacion(int c, int sc, CPU cpu) {
		int suma = sc + c;
		try {
			return cpu.push(suma);
		} catch (StackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Comprueba que sea add y la crea
	 */
	@Override
	protected ByteCode parseOperacion(String s) {
		if (s.equals("ADD"))
			return new Add();
		else
			return null;
	}

	/**
	 * devuelve ADD
	 */
	public String toString() {
		return new String("ADD");
	}
}
