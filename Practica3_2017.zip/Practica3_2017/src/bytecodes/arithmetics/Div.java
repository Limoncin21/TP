package bytecodes.arithmetics;

import bytecodes.ByteCode;
import cpu.CPU;
import exceptions.DivisionByZero;
import exceptions.StackException;

public class Div extends Arithmetics {

	/**
	 * Comprueba que sea div y si es asi la crea
	 */
	@Override
	protected ByteCode parseOperacion(String s) {
		if (s.equals("DIV"))
			return new Div();
		else
			return null;
	}

	/**
	 * operacion de la division
	 * @throws StackException 
	 */
	@Override
	protected boolean operacion(int c, int sc, CPU cpu)throws DivisionByZero, StackException{
		if (c == 0){
			throw new DivisionByZero("Division por 0");
		}
		else{
			int div = sc / c;
			return cpu.push(div);
		}
		
		//faltaria un return false?
	}

	/**
	 * devuelve DIV
	 */
	public String toString() {
		return new String ("DIV");
	}
}
