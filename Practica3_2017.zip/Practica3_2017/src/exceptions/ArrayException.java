package exceptions;

public class ArrayException extends Exception {

	public ArrayException() {

	}

	public ArrayException(String string) {
		// this.message = string;
		super(string);
	}

	// ********************
	public ArrayException(Throwable arg0) {
		super(arg0);
	}

	public ArrayException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	// ********************

	private static final long serialVersionUID = 1L; // para declarar el UID
														// serializable
}
