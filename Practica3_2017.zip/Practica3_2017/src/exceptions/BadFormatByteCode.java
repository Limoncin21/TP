package exceptions;

public class BadFormatByteCode extends Exception {

	public BadFormatByteCode() {

	}

	public BadFormatByteCode(String string) {
		// this.message = string;
		super(string);
	}

	// **********************

	public BadFormatByteCode(Throwable arg0) {
		super(arg0);
	}

	public BadFormatByteCode(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	// **********************

	private static final long serialVersionUID = 1L; // para declarar el UID
														// serializable
}
