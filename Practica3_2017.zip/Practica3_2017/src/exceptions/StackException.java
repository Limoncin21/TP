package exceptions;

public class StackException extends ExecutionError {

	public StackException(){
		super();
	}
	
	public StackException(String string) {
		//this.message = string;
		super(string);
	}

	
	//***************
	public StackException(Throwable arg0){
		super(arg0);
	}
	
	public StackException(String arg0, Throwable arg1){
		super(arg0, arg1);
	}
	//***************
	private static final long serialVersionUID = 1L; // para declarar el UID
														// serializable
}
