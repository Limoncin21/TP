package es.ucm.fdi.tp.was;

import es.ucm.fdi.tp.base.model.GameAction;

public class WolfAndSheepAction implements
		GameAction<WolfAndSheepState, WolfAndSheepAction> {

	private static final long serialVersionUID = -7061739732232203112L;

	private int player;
	private int rowNew;
	private int colNew;
	private int rowOld;
	private int colOld;

	static final int EMPTY = -1;
	final static int LOBO = 0;
	final static int OVEJA = 1;

	/**
	 * Constructor con parametros de un movimiento de un jugador
	 * 
	 * @param player
	 *            jugador
	 * @param rowNew
	 *            fila a mover
	 * @param colNew
	 *            columna a mover
	 * @param rowOld
	 *            fila en la que estaba la pieza
	 * @param colOld
	 *            columna en la que estaba la pieza
	 */
	public WolfAndSheepAction(int player, int rowNew, int colNew, int rowOld,
			int colOld) {
		this.player = player;
		this.rowNew = rowNew;
		this.colNew = colNew;
		this.rowOld = rowOld;
		this.colOld = colOld;
	}

	/**
	 * Devuelve el jugador (0 es el lobo y 1 la oveja)
	 */
	@Override
	public int getPlayerNumber() {
		return player;
	}

	/**
	 * Metodo para pasar turno si no se ha ganado
	 */
	@Override
	public WolfAndSheepState applyTo(WolfAndSheepState state) {
		int[][] board = state.getBoard();
		WolfAndSheepState next = new WolfAndSheepState(state, board, false, -1);

		// make move
		board[rowNew][colNew] = player;
		board[rowOld][colOld] = EMPTY;
		if (WolfAndSheepState.isWinner(next, next.getTurn())) {
			next = new WolfAndSheepState(next, board, true, next.getTurn());
		} else {
			if (state.validActions(OVEJA).isEmpty() && player == OVEJA)
				next = new WolfAndSheepState(next, board, false, LOBO);
		}
		return next;
	}

	/**
	 * Muestra un string con el movimiento de un jugador
	 */
	public String toString() {
		return "place " + player + " at (" + rowNew + ", " + colNew + ")";
	}

}
