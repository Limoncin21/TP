package es.ucm.fdi.tp.launcher;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import es.ucm.fdi.tp.base.console.ConsolePlayer;
import es.ucm.fdi.tp.base.model.GameAction;
import es.ucm.fdi.tp.base.model.GamePlayer;
import es.ucm.fdi.tp.base.model.GameState;
import es.ucm.fdi.tp.base.player.RandomPlayer;
import es.ucm.fdi.tp.base.player.SmartPlayer;
import es.ucm.fdi.tp.ttt.TttState;
import es.ucm.fdi.tp.was.WolfAndSheepState;

public class Main {

	public static void main(String[] args) {

		List<GamePlayer> players = new ArrayList<GamePlayer>();
		GameState<?, ?> state = createInitialState(args[0]);
		System.out.println("Jugador 1. (O)");
		players.add(createPlayer(args[1], "O"));
		System.out.println("Jugador 2. (X)");
		players.add(createPlayer(args[2], "X"));
		System.out.println("Starts the game \n" + state);
		playGame(state, players);

	}

	/**
	 * Inicia el estado del juego
	 * 
	 * @param gameName
	 *            Nombre del juego que quieres jugar
	 * @return Crea el juego indicado
	 */
	public static GameState<?, ?> createInitialState(String gameName) {
		GameState<?, ?> state = null;
		String respuesta = "";
		if (gameName.equals("ttt")) {
			state = new TttState(3);
			respuesta = "Se ha creado correctamente el juego TTT. \n";
		} else if (gameName.equals("was")) {
			state = new WolfAndSheepState();
			respuesta = "Se ha creado correctamente el juego WOLFANDSHEEP. \n";
		} else {
			respuesta = "El juego introducido no es correcto. \n";

		}
		System.out.println(respuesta);
		return state;
	}

	/**
	 * Crea el tipo de jugador indicado (console random o smart)
	 * 
	 * @param PlayerType
	 *            jugador
	 * @param playerName
	 *            tipo de jugador
	 * @return crea el tipo de jugador
	 */
	public static GamePlayer createPlayer(String PlayerType, String playerName) {
		GamePlayer player = null;
		String respuesta = "";
		if (PlayerType.equals("console")) {
			player = new ConsolePlayer(playerName, new Scanner(System.in));
			respuesta = "Se ha creado correctamente el jugador modo CONSOLE. \n";
		} else if (PlayerType.equals("rand")) {
			player = new RandomPlayer(playerName);
			respuesta = "Se ha creado correctamente el jugador modo RAND. \n";
		} else if (PlayerType.equals("smart")) {
			// 5 es lo que habia en el anterior main
			player = new SmartPlayer(playerName, 5);
			respuesta = "Se ha creado correctamente el jugador modo SMART. \n";
		} else {
			respuesta = "El modo de jugador introducido no es valido. \n";
		}
		System.out.println(respuesta);
		return player;
	}

	/**
	 * Inicializa los jugadores y el numero de veces que ha ganado
	 * 
	 * @param initialState
	 *            estado
	 * @param a
	 *            jugador 1
	 * @param b
	 *            jugador 2
	 * @param times
	 *            numero de veces que se ha jugado
	 */
	public static void match(GameState<?, ?> initialState, GamePlayer a,
			GamePlayer b, int times) {
		int va = 0, vb = 0;

		List<GamePlayer> players = new ArrayList<GamePlayer>();
		players.add(a);
		players.add(b);

		for (int i = 0; i < times; i++) {
			switch (playGame(initialState, players)) {
			case 0:
				va++;
				break;
			case 1:
				vb++;
				break;
			}
		}
		System.out.println("Result: " + va + " for " + a.getName() + " vs "
				+ vb + " for " + b.getName());
	}

	/**
	 * Gestiona el juego
	 * 
	 * @param initialState
	 *            estado
	 * @param players
	 *            jugadores
	 * @return devuelve el ganador
	 */
	public static <S extends GameState<S, A>, A extends GameAction<S, A>> int playGame(
			GameState<S, A> initialState, List<GamePlayer> players) {
		int playerCount = 0;
		for (GamePlayer p : players) {
			p.join(playerCount++); // welcome each player, and assign
									// playerNumber
		}
		@SuppressWarnings("unchecked")
		S currentState = (S) initialState;
		A action = null;
		while (!currentState.isFinished()) {
			// request move
			if (!currentState.validActions(currentState.getTurn()).isEmpty()) {
				action = players.get(currentState.getTurn()).requestAction(
						currentState);
			}
			// apply move
			currentState = action.applyTo(currentState);
			System.out.println("After action:\n" + currentState);

			if (currentState.isFinished()) {
				// game over
				String endText = "The game ended: ";
				int winner = currentState.getWinner();
				if (winner == -1) {
					endText += "draw!";
				} else {
					endText += "player " + (winner + 1) + " ("
							+ players.get(winner).getName() + ") won!";
				}
				System.out.println(endText);
			}
		}
		return currentState.getWinner();
	}
}
